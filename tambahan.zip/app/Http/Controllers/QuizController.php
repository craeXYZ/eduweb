<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class QuizController extends Controller
{
    public function showIntro($subject_id)
    {
        $response = Http::get("http://localhost:8080/subject/{$subject_id}");
        $subjects = $response->json();

        return view('pages.subject', compact('subjects'));
    }
}
