<!DOCTYPE html>
<html>
<head>
    <title>Home - My Language Site</title>
</head>
<body>
    <h1>Welcome to the Home Page</h1>
    <a href="/">Home</a> |
    <a href="/about">About</a> |
    <a href="/contact">Contact</a>
</body>
</html>
